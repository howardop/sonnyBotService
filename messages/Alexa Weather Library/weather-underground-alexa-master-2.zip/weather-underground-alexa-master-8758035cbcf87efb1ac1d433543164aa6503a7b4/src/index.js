/**
 Copyright 2016 IBM. All Rights Reserved.
 Developer: David Thomason
 */

/**
 * This application is your personal weather bot.
 *
 */
var APP_NAME = "Weather Underground";

/**
 * App ID for the skill
 */
var APP_ID = 'amzn1.echo-sdk-ams.app.886b247d-81d5-45bd-9848-48a384cd892b';

/**
 * The AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

/**
 * Utility for making requests to the Weather Underground
 */
var weatherUtil = require('./weatherUtil');
var WU_API_KEY = 'b6f5c55d08f5b9ae';
var DEBUG = false;

var locationUtil = require('./locationUtil');

/**
 * WeatherAlexa is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var WeatherAlexa = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
WeatherAlexa.prototype = Object.create(AlexaSkill.prototype);
WeatherAlexa.prototype.constructor = WeatherAlexa;

// ----------------------- Override AlexaSkill request and intent handlers -----------------------

WeatherAlexa.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    console.log("onSessionStarted requestId: " + sessionStartedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any initialization logic goes here
};

WeatherAlexa.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    handleWelcomeRequest(response);
};

WeatherAlexa.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("onSessionEnded requestId: " + sessionEndedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any cleanup logic goes here
};

/**
 * override intentHandlers to map intent handling functions.
 */
WeatherAlexa.prototype.intentHandlers = {
    
    "SmallTalkGreeting": function (intent, session, response) { handleSmallTalk(intent, response) },
    
    "Weather": function (intent, session, response) { getCondition(intent, session, response) },
    "Temperature": function (intent, session, response) { getCondition(intent, session, response) },
    "Rain": function (intent, session, response) { getCondition(intent, session, response) },
    "UV": function (intent, session, response) { getCondition(intent, session, response) },
    "Wind": function (intent, session, response) { getCondition(intent, session, response) },
    "Snow": function (intent, session, response) { getCondition(intent, session, response) },
    "Humidity": function (intent, session, response) { getCondition(intent, session, response) },
    "FeelsLike": function (intent, session, response) { getCondition(intent, session, response) },
    
    "Specify": function (intent, session, response) { getCondition(intent, session, response) },
    
    "AMAZON.HelpIntent": function (intent, session, response) { handleHelpRequest(response); },
    
    "SmallTalkFarewell": function (intent, session, response) { response.tell("Goodbye"); },
    "AMAZON.StopIntent": function (intent, session, response) { response.tell("Goodbye"); },
    "AMAZON.CancelIntent": function (intent, session, response) { response.tell("Goodbye"); }
};

// -------------------------- WeatherAlexa Domain Specific Business Logic --------------------------

function handleWelcomeRequest(response) {
    var whichCityPrompt = "Ask me a question about the weather.",
        speechOutput = {
            speech: "<speak>Welcome to the Weather Underground. My name is " + APP_NAME + ". "
            + whichCityPrompt
            + "</speak>",
            type: AlexaSkill.speechOutputType.SSML
        },
        repromptOutput = {
            speech: "ask a question like, "
            + "get weather information for San Francisco. ",
            type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
    response.ask(speechOutput, repromptOutput);
}

function handleSmallTalk(response) {
    var speechOutput = "Hello, my name is " + APP_NAME + ". Ask me a weather question!";
    var repromptOutput = "Ask me a question such as, 'What is the weather like in San Francisco?'";
    response.ask(speechOutput, repromptOutput);
}

function getCondition(intent, session, response) {
    
    var condition = determineConditionFromIntentOrSession(intent, session);
    var city = getCityFromIntentOrSession(intent, session);
    
    if (city.error) {
        askForCity(response, condition);
    } else {
        
        var state = getStateFromIntentOrSession(intent, session, city);
        var date = getDateFromIntentOrSession(intent, session);
        
        // Issue the request, and respond to the user
        console.log(condition + ',' + city + ','+ state + ',' + date);
        weatherUtil.makeWeatherRequest(WU_API_KEY, condition, city, state, date, DEBUG, function (weather_reply){
            console.log(weather_reply);
            if(weather_reply.ask) response.ask(weather_reply.ask);
            else response.tell(APP_NAME + " says " + weather_reply.tell);
        });
    }
}

/**
 * Determines the condition (weather, temperature, rain, etc.) from the intent,
 * or from the session if the intent is Specify
 */
function determineConditionFromIntentOrSession(intent, session) {
    if (intent.name == "Specify") {
        if (session.attributes.intent) return session.attributes.intent;
        else return "Weather";
    }
    else {
        session.attributes.intent = intent.name;
        return intent.name;
    }
}

/**
 * Gets the city from the intent, or returns an error
 */
function getCityFromIntentOrSession(intent, session) {
    
    var citySlot = intent.slots.City;
    
    // slots can be missing, or slots can be provided but with empty value.
    if (citySlot && citySlot.value) {
        // save the city name to the session and return it
        session.attributes.city = citySlot.value;
        return citySlot.value
        
    } else {
        if (session.attributes.city) return session.attributes.city;
        else return { error: true }
    }
}

/**
 * Gets the state from the intent, or returns null
 */
function getStateFromIntentOrSession(intent, session, city) {
    
    var stateSlot = intent.slots.State;
    var probableState = locationUtil.getProbableState(city, '');    // get the probable state from the city
    
    if (stateSlot && stateSlot.value) { // if there is a state slot,
    
        // save the state name if it is not a proable state to the session and return it
        if(probableState && probableState != stateSlot.value)
            session.attributes.state = stateSlot.value;
        else
            session.attributes.state = null;
        return stateSlot.value;
        
    } else { // otherwise,
        
        if (session.attributes.state) return session.attributes.state;
        
        if (probableState){                                             // if we find a probable state,
            return probableState;                                       // return it
        }
        return null;
    }
}

/**
 * Gets the date from the intent, defaulting to today if none provided,
 * or returns an error
 */
function getDateFromIntentOrSession(intent, session) {
    
    var dateSlot = intent.slots.Date;
    var date;
    
    if (!dateSlot || !dateSlot.value) { // slots can be missing, or slots can be provided but with empty value
        
        if (intent.name == "Specify" && session.attributes.date) { // grab from session if we're specifying
            return session.attributes.date;
        } else { // otherwise default to current
            date = 'current';
        }
    } else {
        date = dateSlot.value;
    }
    session.attributes.date = date;
    return date;
}

/**
 * Get city re-prompt
 */
function askForCity(response, condition) {
    var speechOutput = "Which city would you like " + condition + " information for?";
    response.ask(speechOutput, speechOutput);
}

function handleHelpRequest(response) {
    var repromptText = "Which city would you like weather information for?";
    var speechOutput = "I can lead you through providing a city and "
        + "day of the week to get weather information, "
        + "or you can simply open Weather alexa and ask a question like, "
        + "get weather information for Seattle on Saturday. "
        + "For a list of supported cities, ask what cities are supported. "
        + "Or you can say exit. "
        + repromptText;
    
    response.ask(speechOutput, repromptText);
}

// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
    var weatherAlexa = new WeatherAlexa();
    weatherAlexa.execute(event, context);
};

// function handleSmallTalkTesting(intent, response){
//     var output = "Intent is " + intent.name + " and entities are none";
//     console.log(output);
//     response.tell(output);
// }
//
// function determineIntent(intent, session, response){
//    
//     var citySlot = intent.slots.City;
//     var stateSlot = intent.slots.State;
//     var dateSlot = intent.slots.Date;
//    
//     var hasCity = citySlot && citySlot.value;
//     var hasState = stateSlot && stateSlot.value;
//     var hasDate = dateSlot && dateSlot.value;
//    
//     var output = "Intent is " + intent.name + " and entities are";
//     if (hasCity || hasState || hasDate) {
//         if (hasCity) output += " city: " + citySlot.value;
//         if (hasState) output += " state: " + stateSlot.value;
//         if (hasDate) output += " date: " + dateSlot.value;
//     } else { output += " none"; }
//    
//     console.log(output);
//     response.tell(output);
// }