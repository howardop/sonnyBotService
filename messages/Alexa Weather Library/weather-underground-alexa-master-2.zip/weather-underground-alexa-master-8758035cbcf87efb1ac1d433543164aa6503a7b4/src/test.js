#! /usr/bin/env node

/**
 * Script to test the weather utility.
 * Execute in command line: "node test.js"
 */

/**
 * Utility for making requests to the Weather Underground
 */
var weatherUtil = require('./weatherUtil');

var WU_API_KEY = 'b6f5c55d08f5b9ae';
var condition = 'Temperature';
var city = 'Honolulu';
var state = 'hi';
var date = '2016-06-08';
var debug = true;

console.log();
console.log("Making Weather Request for:");
console.log("condition = " + condition);
console.log("city = " + city);
console.log("state = " + state);
console.log("date = " + date);
console.log();
weatherUtil.makeWeatherRequest(WU_API_KEY, condition, city, state, date, debug, function (weather_reply){
    if(debug) console.log();
    console.log(weather_reply);
});