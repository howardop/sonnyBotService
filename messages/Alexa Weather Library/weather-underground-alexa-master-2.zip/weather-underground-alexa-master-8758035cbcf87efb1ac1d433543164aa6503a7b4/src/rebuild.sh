#!/bin/sh

rm *.zip
zip WeatherAlexa.zip *.js
aws lambda update-function-code --function-name WeatherAlexa --zip-file fileb://./WeatherAlexa.zip